#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd


# In[6]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib
from matplotlib import pyplot as plt


# In[8]:


sales_data = pd.read_csv("C:/Users/HP/Desktop/SalesKaggle3.csv")# Reading the dataset
sales_data.head()# Gist of the dataset


# In[9]:


sales_data.tail()# Gist of the dataset


# In[10]:


sales_data.describe()#Statistical description of the dataset


# In[11]:


sales_data.describe(include='all')# Includes categorical variable 


# In[12]:


print(sales_data.shape)#  Number of enteries 


# In[13]:


print(sales_data.nunique())# Total number of products & unique values of the columns


# In[14]:


# Count of the historical and active state
print(sales_data[sales_data['File_Type'] == 'Historical']['SKU_number'].count())
print(sales_data[sales_data['File_Type'] == 'Active']['SKU_number'].count())


# In[16]:


#  Split the dataset into two parts based on the file_type 
sales_data_hist = sales_data[sales_data['File_Type'] == 'Historical']
sales_data_act = sales_data[sales_data['File_Type'] == 'Active']


# In[17]:


sales_data_hist


# In[18]:


sales_data_act


# In[19]:


#Univariate distribution plots
sales_data['MarketingType'].value_counts().plot.bar(title="Freq dist of Marketing Type")


# In[32]:


sales_data['File_Type'].value_counts().plot.bar(title="Freq dist of File Type")


# In[33]:


sales_data['New_Release_Flag'].value_counts().plot.bar(title="Freq dist of New_Release_Flag")


# In[34]:


sales_data_act['MarketingType'].value_counts().plot.bar(title="Freq dist of MarketingFile Type - active states")


# In[36]:



#To analysis the outliers in the numeric features of the dataset
col_names = ['StrengthFactor','PriceReg', 'ReleaseYear', 'ItemCount', 'LowUserPrice', 'LowNetPrice']

fig, ax = plt.subplots(len(col_names), figsize=(8,40))

for i, col_val in enumerate(col_names):
        
    sns.boxplot(y=sales_data_hist[col_val], ax=ax[i])
    ax[i].set_title('Box plot - '+col_val, fontsize=10)
    ax[i].set_xlabel(col_val, fontsize=8)
    
plt.show()


# In[23]:



#Plots with a kernel density estimate and histogram with bin size determined automatically
col_names = ['StrengthFactor','PriceReg', 'ReleaseYear', 'ItemCount', 'LowUserPrice', 'LowNetPrice']

fig, ax = plt.subplots(len(col_names), figsize=(16,11))

for i, col_val in enumerate(col_names):

    sns.distplot(sales_data_hist[col_val], hist=True, ax=ax[i])
    ax[i].set_title('Freq dist '+col_val, fontsize=9)
    ax[i].set_xlabel(col_val, fontsize=8)
    ax[i].set_ylabel('Count', fontsize=8)

plt.show()


# In[41]:


#missing values detection
sales_data.isnull().values.any()


# In[44]:


sales_data.isnull().sum()




# In[49]:


sales_data['SoldFlag'].fillna(0, inplace=True)
sales_data['SoldCount'].fillna(0, inplace=True)


# In[50]:


sales_data.isnull().sum()


# In[51]:


#Correlation plot
#Positively correlated variables will have correlation value close to +1 and negatively correlated variables will have correlation value close to -1.
f, ax = plt.subplots(figsize=(10, 8))
corr = sales_data_hist.corr()
sns.heatmap(corr, 
            xticklabels=corr.columns.values,
            yticklabels=corr.columns.values)

